// Color palette based on the reference image
module.exports = {
  primary: {
    light: '#FED8CE', // Light pink/coral background
    main: '#FF5733',  // Bright orange/coral for buttons and accents
    dark: '#E64A19',  // Darker shade for hover states
  },
  secondary: {
    light: '#9C27B0',  // Light purple
    main: '#6A1B9A',   // Main purple for footer and buttons
    dark: '#4A148C',   // Dark purple for text on light backgrounds
  },
  background: {
    default: '#FED8CE', // Light pink/coral background
    paper: '#FFFFFF',   // White for cards
  },
  text: {
    primary: '#3E2723',   // Dark brown for primary text
    secondary: '#5D4037', // Medium brown for secondary text
    light: '#FFFFFF',     // White text for dark backgrounds
  },
  rating: {
    star: '#FFC107',      // Gold/yellow for rating stars
  },
  divider: '#EEEEEE',     // Light gray for dividers
}
