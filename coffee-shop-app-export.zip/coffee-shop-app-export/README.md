# Star Coffee Shop App

A responsive coffee shop web application built with Next.js and Tailwind CSS, inspired by the provided design mockup.

## Features

- **Menu Page**: Browse coffee items by category
- **Product Detail Page**: View coffee details, select size, and adjust quantity
- **Shopping Cart**: Review items, adjust quantities, and see order total
- **Responsive Design**: Works on both mobile and desktop devices

## Technologies Used

- **Next.js**: React framework for building the application
- **Tailwind CSS**: For styling components
- **TypeScript**: For type-safe code

## Project Structure

- `src/components/ui/`: Reusable UI components
- `src/app/`: Next.js pages
- `public/images/`: Coffee images and assets

## UI Components

- **CoffeeCard**: Displays coffee items in the menu
- **Sidebar**: Navigation for coffee categories
- **Header**: Page header with navigation controls
- **CartItem**: Individual items in the shopping cart
- **QuantityControl**: Controls for adjusting quantities
- **SizeSelection**: Coffee size selection component
- **IngredientTag**: Displays coffee ingredients
- **Button**: Reusable button component
- **BottomNav**: Bottom navigation bar

## Pages

- **Home/Menu Page**: Browse coffee items by category
- **Product Detail Page**: View coffee details and customize order
- **Cart Page**: Review and modify cart items

## Getting Started

1. Clone the repository
2. Install dependencies:
   ```
   npm install
   ```
3. Run the development server:
   ```
   npm run dev
   ```
4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Deployment

The application is deployed and can be accessed at:
[http://3000-ihacfjvk6jcplmrzilwin-77d5c296.manus.computer](http://3000-ihacfjvk6jcplmrzilwin-77d5c296.manus.computer)

## Screenshots

The application closely follows the design in the provided mockup, featuring:
- Pink/coral color scheme with purple accents
- Clean card-based design for coffee items
- Intuitive navigation and user interface
