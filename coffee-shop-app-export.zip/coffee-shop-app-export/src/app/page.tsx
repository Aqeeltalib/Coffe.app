import React, { useState } from 'react';
import { Header } from '@/components/ui/Header';
import { Sidebar } from '@/components/ui/Sidebar';
import { CoffeeCard } from '@/components/ui/CoffeeCard';
import { BottomNav } from '@/components/ui/BottomNav';

interface Coffee {
  id: string;
  name: string;
  description: string;
  price: number;
  rating: number;
  image: string;
  category: string;
}

export default function HomePage() {
  const [activeCategory, setActiveCategory] = useState('hot-coffee');
  const [activeTab, setActiveTab] = useState('home');
  
  const coffeeItems: Coffee[] = [
    {
      id: '1',
      name: 'Espresso',
      description: 'with milk',
      price: 75.00,
      rating: 4.6,
      image: '/images/espresso.jpg',
      category: 'hot-coffee',
    },
    {
      id: '2',
      name: 'Cappuccino',
      description: '70 % with milk',
      price: 85.00,
      rating: 4.6,
      image: '/images/cappuccino.jpg',
      category: 'hot-coffee',
    },
    {
      id: '3',
      name: 'Star Bucks',
      description: 'with whole milk',
      price: 125.00,
      rating: 4.6,
      image: '/images/coffee-beans.jpg',
      category: 'hot-coffee',
    },
    {
      id: '4',
      name: 'Latte',
      description: 'with bakery',
      price: 100.00,
      rating: 4.6,
      image: '/images/cappuccino.jpg',
      category: 'hot-coffee',
    },
  ];

  const handleAddToCart = (id: string) => {
    console.log(`Added coffee with id ${id} to cart`);
    // In a real app, this would update the cart state
  };

  const filteredCoffee = coffeeItems.filter(
    (coffee) => coffee.category === activeCategory
  );

  return (
    <div className="flex h-screen bg-pink-100">
      <Sidebar activeCategory={activeCategory} onCategoryChange={setActiveCategory} />
      
      <div className="flex-1 flex flex-col">
        <Header 
          title="Star Coffee" 
          showSearchButton={true}
        />
        
        <div className="p-4">
          <div className="mb-4">
            <h2 className="text-orange-600">Welcome</h2>
            <h1 className="text-2xl font-bold">Subash</h1>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            {filteredCoffee.map((coffee) => (
              <CoffeeCard
                key={coffee.id}
                id={coffee.id}
                name={coffee.name}
                description={coffee.description}
                price={coffee.price}
                rating={coffee.rating}
                image={coffee.image}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        </div>
        
        <div className="mt-auto">
          <div className="bg-purple-800 rounded-t-3xl overflow-hidden">
            <div className="flex justify-center -mt-6">
              <button className="bg-orange-500 text-white p-4 rounded-full shadow-lg">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                </svg>
              </button>
            </div>
            <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
          </div>
        </div>
      </div>
    </div>
  );
}
