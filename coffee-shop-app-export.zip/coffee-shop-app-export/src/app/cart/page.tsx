import React, { useState } from 'react';
import { Header } from '@/components/ui/Header';
import { CartItem } from '@/components/ui/CartItem';
import { Button } from '@/components/ui/Button';

interface CartItemType {
  id: string;
  name: string;
  description: string;
  price: number;
  quantity: number;
  image: string;
}

export default function CartPage() {
  // In a real app, this would come from a global cart state
  const [cartItems, setCartItems] = useState<CartItemType[]>([
    {
      id: '1',
      name: 'Espresso',
      description: 'with milk',
      price: 75.00,
      quantity: 1,
      image: '/images/espresso.jpg',
    },
    {
      id: '4',
      name: 'Latte',
      description: 'with bakery',
      price: 100.00,
      quantity: 1,
      image: '/images/cappuccino.jpg',
    },
  ]);

  const handleIncrement = (id: string) => {
    setCartItems(
      cartItems.map((item) =>
        item.id === id ? { ...item, quantity: item.quantity + 1 } : item
      )
    );
  };

  const handleDecrement = (id: string) => {
    setCartItems(
      cartItems.map((item) =>
        item.id === id && item.quantity > 1
          ? { ...item, quantity: item.quantity - 1 }
          : item
      ).filter((item) => !(item.id === id && item.quantity === 1))
    );
  };

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );
  
  const shippingCost = 50.00;
  const taxes = 50.00;
  const total = subtotal + shippingCost + taxes;

  return (
    <div className="flex flex-col h-screen bg-pink-100">
      <Header 
        title="Cart" 
        showBackButton={true}
        showEditButton={true}
        onBackClick={() => console.log('Back clicked')}
        onEditClick={() => console.log('Edit clicked')}
      />
      
      <div className="flex-1 p-4">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">My Order</h1>
          <p>You have {cartItems.length} items in your cart</p>
        </div>
        
        <div className="space-y-4">
          {cartItems.map((item) => (
            <CartItem
              key={item.id}
              id={item.id}
              name={item.name}
              description={item.description}
              price={item.price}
              quantity={item.quantity}
              image={item.image}
              onIncrement={handleIncrement}
              onDecrement={handleDecrement}
            />
          ))}
        </div>
      </div>
      
      <div className="bg-gradient-to-b from-pink-100 to-orange-500 rounded-t-3xl p-4">
        <div className="bg-orange-500 rounded-t-3xl p-4 text-white">
          <div className="mb-4">
            <div className="flex justify-between mb-2">
              <span>Subtotal</span>
              <span>Rs : {subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span>Shipping Cost</span>
              <span>Rs : {shippingCost.toFixed(2)}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span>Taxes</span>
              <span>Rs : {taxes.toFixed(2)}</span>
            </div>
            <div className="h-px bg-white opacity-20 my-2"></div>
            <div className="flex justify-between font-bold">
              <span>Total</span>
              <span>Rs : {total.toFixed(2)}</span>
            </div>
          </div>
          
          <div className="bg-purple-800 rounded-xl p-4 text-center">
            <div className="text-white font-bold mb-2">Rs : {total.toFixed(2)}</div>
            <Button
              variant="secondary"
              size="lg"
              fullWidth
              onClick={() => console.log('Proceed to checkout')}
            >
              Proceed to checkout
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
