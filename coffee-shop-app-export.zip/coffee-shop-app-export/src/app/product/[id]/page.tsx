import React, { useState } from 'react';
import { Header } from '@/components/ui/Header';
import { SizeSelection } from '@/components/ui/SizeSelection';
import { QuantityControl } from '@/components/ui/QuantityControl';
import { IngredientTag } from '@/components/ui/IngredientTag';
import { Button } from '@/components/ui/Button';
import Image from 'next/image';

export default function ProductDetailPage({ params }: { params: { id: string } }) {
  const [quantity, setQuantity] = useState(5);
  const [selectedSize, setSelectedSize] = useState('medium');
  
  // In a real app, this would fetch the product based on the ID
  const product = {
    id: '1',
    name: 'Cappuccino',
    description: 'Rich espresso with steamed milk and a deep layer of foam',
    price: 125.00,
    image: '/images/cappuccino.jpg',
  };

  const sizes = [
    { id: 'small', name: 'Small', icon: '🥤' },
    { id: 'medium', name: 'Medium', icon: '☕' },
    { id: 'large', name: 'Large', icon: '🍵' },
  ];

  const ingredients = [
    { name: 'Milk', icon: '🥛' },
  ];

  const handleAddToCart = () => {
    console.log(`Added ${quantity} ${selectedSize} ${product.name} to cart`);
    // In a real app, this would update the cart state
  };

  return (
    <div className="flex flex-col h-screen bg-pink-100">
      <Header 
        title="Cart" 
        showBackButton={true}
        onBackClick={() => console.log('Back clicked')}
      />
      
      <div className="relative w-full h-72">
        <Image
          src={product.image}
          alt={product.name}
          fill
          className="object-cover"
        />
        <button className="absolute top-4 right-4 bg-white p-2 rounded-full">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
          </svg>
        </button>
      </div>
      
      <div className="flex-1 p-4 rounded-t-3xl -mt-6 bg-pink-100">
        <h1 className="text-2xl font-bold mb-2">{product.name}</h1>
        
        <div className="mt-4">
          <h3 className="text-xl font-semibold mb-4">Ingredients</h3>
          <div className="flex space-x-4">
            {ingredients.map((ingredient) => (
              <IngredientTag
                key={ingredient.name}
                name={ingredient.name}
                icon={ingredient.icon}
              />
            ))}
          </div>
        </div>
        
        <SizeSelection
          sizes={sizes}
          selectedSize={selectedSize}
          onSizeSelect={setSelectedSize}
        />
        
        <div className="mt-6 flex justify-between items-center">
          <QuantityControl
            quantity={quantity}
            onIncrement={() => setQuantity(quantity + 1)}
            onDecrement={() => quantity > 1 && setQuantity(quantity - 1)}
            size="lg"
          />
          <div className="text-xl font-bold">Rs : {product.price.toFixed(2)}</div>
        </div>
        
        <div className="mt-8 bg-purple-800 rounded-t-3xl p-4 text-center">
          <div className="text-white mb-2">Rs : {product.price.toFixed(2)}</div>
          <Button
            variant="primary"
            size="lg"
            fullWidth
            onClick={handleAddToCart}
          >
            Add to cart
          </Button>
        </div>
      </div>
    </div>
  );
}
