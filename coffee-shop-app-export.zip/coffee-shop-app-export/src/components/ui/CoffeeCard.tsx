import React from 'react';
import Image from 'next/image';
import { Star } from 'lucide-react';

interface CoffeeCardProps {
  id: string;
  name: string;
  description: string;
  price: number;
  rating: number;
  image: string;
  onAddToCart: (id: string) => void;
}

export const CoffeeCard: React.FC<CoffeeCardProps> = ({
  id,
  name,
  description,
  price,
  rating,
  image,
  onAddToCart,
}) => {
  return (
    <div className="bg-white rounded-xl p-4 shadow-sm">
      <div className="relative w-full h-40 mb-3">
        <Image
          src={image}
          alt={name}
          fill
          className="rounded-lg object-cover"
        />
      </div>
      <h3 className="text-xl font-semibold">{name}</h3>
      <p className="text-sm text-gray-600 mb-2">{description}</p>
      <div className="flex items-center mb-2">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            size={16}
            className={`${
              i < Math.floor(rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'
            }`}
          />
        ))}
        <span className="ml-1 text-sm text-gray-600">{rating}</span>
      </div>
      <div className="flex justify-between items-center">
        <p className="font-semibold">Rs : {price.toFixed(2)}</p>
        <button
          onClick={() => onAddToCart(id)}
          className="bg-orange-500 text-white p-2 rounded-full"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <line x1="5" y1="12" x2="19" y2="12"></line>
          </svg>
        </button>
      </div>
    </div>
  );
};
