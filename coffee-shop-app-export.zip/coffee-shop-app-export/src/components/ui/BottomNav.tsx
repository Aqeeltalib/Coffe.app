import React from 'react';

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
}) => {
  const tabs = [
    { id: 'home', icon: '🏠' },
    { id: 'menu', icon: '📖' },
    { id: 'favorites', icon: '❤️' },
    { id: 'profile', icon: '👤' },
  ];

  return (
    <div className="flex justify-around items-center bg-purple-800 text-white py-3 rounded-t-xl">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          className={`p-2 ${activeTab === tab.id ? 'opacity-100' : 'opacity-60'}`}
          onClick={() => onTabChange(tab.id)}
        >
          <span className="text-xl">{tab.icon}</span>
        </button>
      ))}
    </div>
  );
};
