import React from 'react';

interface SidebarProps {
  activeCategory: string;
  onCategoryChange: (category: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeCategory,
  onCategoryChange,
}) => {
  const categories = [
    { id: 'hot-teas', name: 'Hot Teas', icon: '🍵' },
    { id: 'hot-coffee', name: 'Hot Coffee', icon: '☕' },
    { id: 'ice-teas', name: 'Ice Teas', icon: '🧊' },
    { id: 'drinks', name: 'Drinks', icon: '🥤' },
    { id: 'bakery', name: 'Bakery', icon: '🥐' },
  ];

  return (
    <div className="h-full bg-orange-600 text-white flex flex-col w-16">
      {categories.map((category) => (
        <button
          key={category.id}
          className={`py-6 flex flex-col items-center justify-center text-xs ${
            activeCategory === category.id ? 'bg-orange-700' : ''
          }`}
          onClick={() => onCategoryChange(category.id)}
        >
          <span className="text-xl mb-1">{category.icon}</span>
          <div className="writing-mode-vertical transform rotate-180 whitespace-nowrap">
            {category.name}
          </div>
          {activeCategory === category.id && (
            <div className="absolute left-0 w-1 h-6 bg-white"></div>
          )}
        </button>
      ))}
    </div>
  );
};
