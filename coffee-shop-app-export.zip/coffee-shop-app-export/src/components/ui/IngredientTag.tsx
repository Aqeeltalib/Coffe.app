import React from 'react';

interface IngredientTagProps {
  name: string;
  icon: string;
}

export const IngredientTag: React.FC<IngredientTagProps> = ({
  name,
  icon,
}) => {
  return (
    <div className="flex flex-col items-center">
      <div className="bg-orange-500 text-white p-3 rounded-full mb-2">
        <div dangerouslySetInnerHTML={{ __html: icon }} />
      </div>
      <span className="text-sm text-orange-500">{name}</span>
    </div>
  );
};
