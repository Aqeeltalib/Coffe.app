import React from 'react';

interface SizeSelectionProps {
  sizes: { id: string; name: string; icon: string }[];
  selectedSize: string;
  onSizeSelect: (sizeId: string) => void;
}

export const SizeSelection: React.FC<SizeSelectionProps> = ({
  sizes,
  selectedSize,
  onSizeSelect,
}) => {
  return (
    <div className="mt-4">
      <h3 className="text-xl font-semibold mb-4">Coffee Size</h3>
      <div className="flex justify-between">
        {sizes.map((size) => (
          <button
            key={size.id}
            className={`flex flex-col items-center p-3 rounded-lg ${
              selectedSize === size.id
                ? 'bg-orange-500 text-white'
                : 'bg-white text-gray-700 border border-gray-200'
            }`}
            onClick={() => onSizeSelect(size.id)}
          >
            <div className="text-2xl mb-2" dangerouslySetInnerHTML={{ __html: size.icon }} />
            <span className="text-sm">{size.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
