import React from 'react';
import Image from 'next/image';

interface CartItemProps {
  id: string;
  name: string;
  description: string;
  price: number;
  quantity: number;
  image: string;
  onIncrement: (id: string) => void;
  onDecrement: (id: string) => void;
}

export const CartItem: React.FC<CartItemProps> = ({
  id,
  name,
  description,
  price,
  quantity,
  image,
  onIncrement,
  onDecrement,
}) => {
  return (
    <div className="bg-white rounded-xl p-4 mb-4 shadow-sm">
      <div className="flex items-center">
        <div className="relative w-16 h-16 mr-4">
          <Image
            src={image}
            alt={name}
            fill
            className="rounded-lg object-cover"
          />
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold">{name}</h3>
          <p className="text-sm text-gray-600">{description}</p>
          <p className="font-semibold text-orange-500">Rs : {price.toFixed(2)}</p>
        </div>
        <div className="flex items-center">
          <button
            onClick={() => onDecrement(id)}
            className="bg-pink-100 text-orange-500 p-2 rounded-lg"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
          </button>
          <span className="mx-3">{quantity}</span>
          <button
            onClick={() => onIncrement(id)}
            className="bg-pink-100 text-orange-500 p-2 rounded-lg"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};
