import React from 'react';
import { ChevronLeft, Edit } from 'lucide-react';

interface HeaderProps {
  title: string;
  showBackButton?: boolean;
  showSearchButton?: boolean;
  showEditButton?: boolean;
  onBackClick?: () => void;
  onSearchClick?: () => void;
  onEditClick?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  showBackButton = false,
  showSearchButton = false,
  showEditButton = false,
  onBackClick,
  onSearchClick,
  onEditClick,
}) => {
  return (
    <div className="flex items-center justify-between p-4 bg-pink-100">
      <div className="flex items-center">
        {showBackButton && (
          <button 
            onClick={onBackClick}
            className="mr-2 bg-orange-500 text-white p-2 rounded-full"
          >
            <ChevronLeft size={20} />
          </button>
        )}
        <h1 className="text-2xl font-bold text-gray-800">{title}</h1>
      </div>
      <div className="flex items-center">
        {showSearchButton && (
          <button 
            onClick={onSearchClick}
            className="ml-2 text-orange-500"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
          </button>
        )}
        {showEditButton && (
          <button 
            onClick={onEditClick}
            className="ml-2 bg-orange-500 text-white p-2 rounded-full"
          >
            <Edit size={20} />
          </button>
        )}
      </div>
    </div>
  );
};
